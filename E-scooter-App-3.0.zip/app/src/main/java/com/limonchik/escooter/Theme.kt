package com.limonchik.escooter

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val cyan = Color(0xFF22D3EE)
    val violet = Color(0xFF8B5CF6)
    val green = Color(0xFF34D399)
    val amber = Color(0xFFFBBF24)
    val red = Color(0xFFF87171)
}

@Composable
fun EScooterTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 0 -> isSystemInDarkTheme(); else -> true }
    val cs = if (dark) darkColorScheme(
        primary = Pal.cyan, secondary = Pal.violet, error = Pal.red,
        background = Color(0xFF060A12), surface = Color(0xFF0E1524), surfaceVariant = Color(0xFF18223A),
        onBackground = Color(0xFFEAF2FF), onSurface = Color(0xFFEAF2FF), onSurfaceVariant = Color(0xFF8FA0BC)
    ) else lightColorScheme(
        primary = Color(0xFF0891B2), secondary = Color(0xFF6D4AE0), error = Color(0xFFDC2626),
        background = Color(0xFFF3F6FC), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFE4EAF6),
        onBackground = Color(0xFF0B1220), onSurface = Color(0xFF0B1220), onSurfaceVariant = Color(0xFF55627A)
    )
    MaterialTheme(colorScheme = cs, content = content)
}
