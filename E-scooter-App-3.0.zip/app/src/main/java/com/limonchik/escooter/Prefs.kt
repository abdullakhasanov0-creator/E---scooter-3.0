package com.limonchik.escooter

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("escooter", Context.MODE_PRIVATE)
    var scooter: String? get() = sp.getString("scooter", null); set(v) { sp.edit().putString("scooter", v).apply() }
    var username: String? get() = sp.getString("username", null); set(v) { sp.edit().putString("username", v).apply() }
    var lastAddr: String? get() = sp.getString("lastAddr", null); set(v) { sp.edit().putString("lastAddr", v).apply() }
    var onboarded: Boolean get() = sp.getBoolean("onboarded", false); set(v) { sp.edit().putBoolean("onboarded", v).apply() }
    var userAsked: Boolean get() = sp.getBoolean("userAsked", false); set(v) { sp.edit().putBoolean("userAsked", v).apply() }
    var botSent: Boolean get() = sp.getBoolean("botSent", false); set(v) { sp.edit().putBoolean("botSent", v).apply() }
    var tgPrompted: Boolean get() = sp.getBoolean("tgPrompted", false); set(v) { sp.edit().putBoolean("tgPrompted", v).apply() }
    var theme: Int get() = sp.getInt("theme", 2); set(v) { sp.edit().putInt("theme", v).apply() }
    var mph: Boolean get() = sp.getBoolean("mph", false); set(v) { sp.edit().putBoolean("mph", v).apply() }
    var keepOn: Boolean get() = sp.getBoolean("keepOn", false); set(v) { sp.edit().putBoolean("keepOn", v).apply() }
    var lowAlert: Boolean get() = sp.getBoolean("lowAlert", true); set(v) { sp.edit().putBoolean("lowAlert", v).apply() }
    var speedAlert: Int get() = sp.getInt("speedAlert", 0); set(v) { sp.edit().putInt("speedAlert", v).apply() }
    var strobeMode: Int get() = sp.getInt("strobeMode", 0); set(v) { sp.edit().putInt("strobeMode", v).apply() }
    var strobeSpeed: Float get() = sp.getFloat("strobeSpeed", 1f); set(v) { sp.edit().putFloat("strobeSpeed", v).apply() }
}
