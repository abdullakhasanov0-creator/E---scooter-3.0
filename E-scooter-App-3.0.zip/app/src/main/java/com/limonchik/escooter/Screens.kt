@file:OptIn(ExperimentalMaterial3Api::class)

package com.limonchik.escooter

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

const val TG_CHANNEL = "https://t.me/EscooterOfficial"
const val TG_BOT = "https://t.me/EScooterApp_bot"
const val TG_SUPPORT = "https://t.me/EScooterApp_bot?start=support"

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

/** Бот открывается с /start "<username>-<Model>", чтобы START отправил всё автоматически. */
fun botLink(user: String, model: String): String {
    val u = user.trim().removePrefix("@").filter { it in 'a'..'z' || it in 'A'..'Z' || it in '0'..'9' || it == '_' }
    val m = model.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
    val p = (u + if (u.isNotEmpty() && m.isNotEmpty()) "-$m" else "").take(64)
    return if (p.isEmpty()) TG_BOT else "$TG_BOT?start=$p"
}

@Suppress("DEPRECATION")
fun buzz(ctx: Context, ms: Long = 300) {
    try { (ctx.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator)?.vibrate(ms) } catch (_: Throwable) {}
}

fun brandColor(b: String): Color = when (b) {
    "Kugoo" -> Color(0xFFFF8A3D); "Ninebot" -> Color(0xFF38BDF8); "Xiaomi" -> Color(0xFFFF6B6B); else -> Pal.violet
}

// ---------------- Building blocks ----------------
@Composable
fun Bg(content: @Composable ColumnScope.() -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.background, c.surface)))) {
        Box(
            Modifier.size(320.dp).align(Alignment.TopEnd).offset(90.dp, (-90).dp)
                .background(Brush.radialGradient(listOf(Pal.violet.copy(alpha = .28f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.size(280.dp).align(Alignment.BottomStart).offset((-90).dp, 90.dp)
                .background(Brush.radialGradient(listOf(Pal.cyan.copy(alpha = .18f), Color.Transparent)), CircleShape)
        )
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp), content = content)
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.clip(shape).background(c.surfaceVariant.copy(alpha = .65f))
            .border(1.dp, c.onSurface.copy(alpha = .08f), shape).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp), content = content
    )
}

@Composable
fun SectionTitle(t: String) {
    Text(t, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
}

@Composable
fun GradButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier.height(56.dp).clip(RoundedCornerShape(18.dp))
            .background(Brush.horizontalGradient(listOf(Pal.cyan, Pal.violet)))
            .alpha(if (enabled) 1f else .4f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.onSurface, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier.height(52.dp).clip(RoundedCornerShape(18.dp)).border(1.dp, c.onSurface.copy(alpha = .2f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = color, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun ActionTile(icon: String, label: String, on: Boolean, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val bg = if (on) Brush.linearGradient(listOf(Pal.cyan, Pal.violet)) else Brush.linearGradient(listOf(c.surfaceVariant, c.surfaceVariant))
    Box(
        modifier.height(88.dp).clip(RoundedCornerShape(22.dp)).background(bg)
            .alpha(if (enabled) 1f else .45f).clickable(enabled = enabled, onClick = onClick).padding(14.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Text(icon, fontSize = 26.sp)
            Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = if (on) Color.White else c.onSurface)
        }
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(c.surfaceVariant.copy(alpha = .65f)).padding(vertical = 12.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text(label, color = c.onSurfaceVariant, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun BatteryBar(pct: Int, color: Color) {
    val c = MaterialTheme.colorScheme
    val f = (pct / 100f).coerceIn(0.02f, 1f)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("🔋", fontSize = 16.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(10.dp).clip(RoundedCornerShape(5.dp)).background(c.surfaceVariant)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(f).clip(RoundedCornerShape(5.dp)).background(color))
        }
        Spacer(Modifier.width(10.dp))
        Text("$pct%", fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun Gauge(value: Float, max: Float, text: String, unit: String, track: Color) {
    val anim by animateFloatAsState(value, tween(450), label = "gauge")
    Box(Modifier.size(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 26.dp.toPx()
            val sz = Size(size.width - stroke, size.height - stroke)
            val tl = Offset(stroke / 2, stroke / 2)
            drawArc(track, 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            val sweep = 270f * (anim / max).coerceIn(0f, 1f)
            if (sweep > 0.5f) drawArc(
                Brush.sweepGradient(listOf(Pal.cyan, Pal.violet, Pal.cyan)), 135f, sweep, false, tl, sz,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text, fontSize = 76.sp, fontWeight = FontWeight.Black)
            Text(unit, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 16.sp)
        }
    }
}

@Composable
fun StepHeader(title: String, sub: String, step: Int) {
    val c = MaterialTheme.colorScheme
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 14.dp)) {
        for (i in 1..2) Box(
            Modifier.height(5.dp).width(if (i == step) 34.dp else 18.dp).clip(RoundedCornerShape(3.dp))
                .background(if (i <= step) Pal.cyan else c.surfaceVariant)
        )
    }
    Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
    Text(sub, color = c.onSurfaceVariant)
    Spacer(Modifier.height(14.dp))
}

// ---------------- Onboarding ----------------
@Composable
fun Onboarding(vm: MainViewModel) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(if (vm.userAsked) 1 else 0) }
    var sel by rememberSaveable { mutableStateOf(vm.scooter ?: "") }
    if (step == 0) BotStep(vm) { step = 1 }
    else PickerStep(sel, { sel = it }) {
        vm.changeScooter(sel.trim())
        vm.finishOnboarding()
        vm.registerOnce(ctx)
    }
}

@Composable
fun BotStep(vm: MainViewModel, next: () -> Unit) {
    val c = MaterialTheme.colorScheme
    var u by rememberSaveable { mutableStateOf("") }
    Bg {
        StepHeader("Добро пожаловать 👋", "Напишите в бот @EScooterApp_bot свой юзернейм и модель самоката", 1)
        OutlinedTextField(u, { u = it }, label = { Text("Ваш юзернейм Telegram") }, prefix = { Text("@") },
            singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        Glass(Modifier.fillMaxWidth()) {
            SectionTitle("Как это работает")
            Text("1. Введите юзернейм и нажмите «Далее».\n2. Выберите свой самокат.\n3. Откроется бот — нажмите START, юзернейм и модель отправятся сами.\n\nМожно и вручную: просто напишите боту @юзернейм и модель.",
                color = c.onSurfaceVariant, fontSize = 14.sp)
        }
        Spacer(Modifier.weight(1f))
        GradButton("Далее", Modifier.fillMaxWidth(), enabled = u.isNotBlank()) { vm.saveUser(u); next() }
        TextButton({ next() }, Modifier.fillMaxWidth()) { Text("Пропустить") }
    }
}

@Composable
fun PickerStep(sel: String, onSel: (String) -> Unit, onNext: () -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    var brand by rememberSaveable { mutableStateOf("Все") }
    var custom by rememberSaveable { mutableStateOf(false) }
    var customText by rememberSaveable { mutableStateOf("") }
    val list = Scooters.all.filter { (brand == "Все" || it.brand == brand) && it.name.contains(q, true) }
    Bg {
        StepHeader("Ваш самокат", "Выберите модель — подберём настройки соединения", 2)
        OutlinedTextField(q, { q = it }, placeholder = { Text("Поиск модели") }, singleLine = true,
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth())
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Все", "Kugoo", "Ninebot", "Xiaomi").forEach {
                FilterChip(selected = brand == it, onClick = { brand = it }, label = { Text(it) })
            }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { s -> ModelCard(s.name, s.brand, sel == s.name && !custom) { custom = false; onSel(s.name) } }
            item { ModelCard("Другой вариант", "", custom) { custom = true; onSel(customText) } }
        }
        if (custom) OutlinedTextField(customText, { customText = it; onSel(it) }, label = { Text("Название вашего самоката") },
            singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        Spacer(Modifier.height(10.dp))
        GradButton("Далее", Modifier.fillMaxWidth(), enabled = sel.isNotBlank(), onClick = onNext)
    }
}

@Composable
fun ModelCard(title: String, brand: String, on: Boolean, click: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (on) Pal.cyan.copy(alpha = .16f) else c.surfaceVariant.copy(alpha = .65f))
            .border(if (on) 2.dp else 1.dp, if (on) Pal.cyan else c.onSurface.copy(alpha = .06f), shape)
            .clickable(onClick = click).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(brandColor(brand).copy(alpha = .25f)), contentAlignment = Alignment.Center) {
            Text(if (brand.isEmpty()) "✏️" else brand.take(1), fontWeight = FontWeight.Bold, color = brandColor(brand))
        }
        Spacer(Modifier.width(12.dp))
        Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium)
        if (on) Text("✓", color = Pal.cyan, fontWeight = FontWeight.Bold)
    }
}

// ---------------- Main ----------------
@Composable
fun MainScreen(vm: MainViewModel, requestScan: () -> Unit) {
    val ctx = LocalContext.current
    val ble = vm.ble
    val st by ble.state.collectAsState()
    val t by ble.data.collectAsState()
    val noData by ble.noData.collectAsState()
    val protoOk by ble.protoOk.collectAsState()
    val light by ble.light.collectAsState()
    val locked by ble.locked.collectAsState()
    val msg by ble.msg.collectAsState()
    val info by ble.info.collectAsState()
    val strobe by ble.strobe.collectAsState()
    val stats by ble.stats.collectAsState()
    val kers by ble.kers.collectAsState()
    val cruise by ble.cruise.collectAsState()
    var settings by remember { mutableStateOf(false) }
    var diag by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var about by remember { mutableStateOf(false) }
    var confirmOff by remember { mutableStateOf(false) }
    val c = MaterialTheme.colorScheme
    val prof = profileFor(vm.scooter)
    val on = st == ConnState.CONNECTED
    val live = on && protoOk
    val parked = live && t.speed < 0.5f
    val k = if (vm.mph) 0.621371f else 1f
    val spd = t.speed * k
    val dist = if (vm.mph) "mi" else "км"
    val su = if (vm.mph) "mph" else "км/ч"
    val batColor = when { t.battery > 50 -> Pal.green; t.battery > 20 -> Pal.amber; else -> Pal.red }
    val statusText = when (st) {
        ConnState.IDLE -> "Не подключён"; ConnState.SCANNING -> "Поиск…"; ConnState.CONNECTING -> "Подключение…"
        ConnState.CONNECTED -> if (protoOk) "Подключён" else "Связь есть, жду данные"; ConnState.ERROR -> "Ошибка соединения"
    }
    val statusColor = when (st) {
        ConnState.CONNECTED -> if (protoOk) Pal.green else Pal.amber; ConnState.ERROR -> Pal.red
        ConnState.IDLE -> c.onSurfaceVariant; else -> Pal.amber
    }
    val over = live && vm.speedAlert > 0 && t.speed > vm.speedAlert
    LaunchedEffect(over) { if (over) buzz(ctx) }
    val low = live && vm.lowAlert && t.battery in 1..15
    LaunchedEffect(low) { if (low) buzz(ctx, 700) }

    Bg {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("МОЙ САМОКАТ", color = Pal.cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text(vm.scooter ?: "—", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
            }
            Box {
                IconButton({ menu = true }) { Text("⋮", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Диагностика") }, { menu = false; diag = true })
                    DropdownMenuItem({ Text("Настройки") }, { menu = false; settings = true })
                    DropdownMenuItem({ Text("Связь с разработчиком") }, { menu = false; openUrl(ctx, TG_SUPPORT) })
                    DropdownMenuItem({ Text("Сменить самокат") }, { menu = false; vm.changeScooter() })
                    DropdownMenuItem({ Text("Telegram-канал") }, { menu = false; openUrl(ctx, TG_CHANNEL) })
                    DropdownMenuItem({ Text("О приложении") }, { menu = false; about = true })
                }
            }
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(statusColor))
                Spacer(Modifier.width(8.dp))
                Text(statusText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
            Text(
                prof.family.title + if (info.fw.isNotEmpty()) " · FW ${info.fw}" else "",
                color = c.onSurfaceVariant, fontSize = 11.sp, textAlign = TextAlign.Center
            )
            if (msg.isNotEmpty()) Text(msg, color = Pal.amber, fontSize = 13.sp, textAlign = TextAlign.Center)
            Gauge(
                value = spd, max = if (vm.mph) 25f else 40f,
                text = if (live) "%.0f".format(spd) else "--", unit = if (live) su else "", track = c.surfaceVariant
            )
            if (live) {
                BatteryBar(t.battery, batColor)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatTile("Поездка, $dist", "%.1f".format(t.trip * k), Modifier.weight(1f))
                    StatTile("Всего, $dist", "%.0f".format(t.total * k), Modifier.weight(1f))
                    StatTile("Темп., °C", "%.0f".format(t.temp), Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("💡", "Свет", light, live, Modifier.weight(1f)) { ble.setLight(!light) }
                ActionTile(if (locked) "🔒" else "🔓", if (locked) "Закрыт" else "Замок", locked, live, Modifier.weight(1f)) { ble.setLock(!locked) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile("⚡", "Стробоскоп", strobe, parked || strobe, Modifier.weight(1f)) {
                    if (strobe) ble.stopStrobe() else ble.startStrobe(StrobeMode.values()[vm.strobeMode], 1f / vm.strobeSpeed)
                }
                ActionTile("📢", if (vm.beeping) "Пищит… (стоп)" else "Сигнал", vm.beeping, true, Modifier.weight(1f)) { vm.toggleBeep() }
            }
            if (live) {
                Glass(Modifier.fillMaxWidth()) {
                    SectionTitle("⚡ Стробоскоп")
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StrobeMode.values().forEach { m ->
                            FilterChip(vm.strobeMode == m.ordinal, { vm.changeStrobeMode(m.ordinal) }, { Text(m.title, fontSize = 12.sp) })
                        }
                    }
                    Text("Скорость мигания ×%.1f".format(vm.strobeSpeed), fontSize = 12.sp, color = c.onSurfaceVariant)
                    Slider(vm.strobeSpeed, { vm.changeStrobeSpeed(it) }, valueRange = 0.5f..2.5f)
                    Text("Работает на стоянке, при движении выключается сам.", fontSize = 11.sp, color = c.onSurfaceVariant)
                }
                Glass(Modifier.fillMaxWidth()) {
                    SectionTitle("🔋 Рекуперация и круиз")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Слабая", "Средняя", "Сильная").forEachIndexed { i, n ->
                            FilterChip(kers == i, { ble.setKers(i) }, { Text(n, fontSize = 12.sp) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Круиз-контроль", Modifier.weight(1f)); Switch(cruise, { ble.setCruise(it) })
                    }
                }
                val avg = if (stats.n > 0) stats.sum / stats.n else 0f
                val mins = if (stats.startMs > 0) (System.currentTimeMillis() - stats.startMs) / 60000 else 0
                Glass(Modifier.fillMaxWidth()) {
                    SectionTitle("📊 Сессия")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("Макс, $su", "%.1f".format(stats.max * k), Modifier.weight(1f))
                        StatTile("Средняя, $su", "%.1f".format(avg * k), Modifier.weight(1f))
                        StatTile("Время, мин", "$mins", Modifier.weight(1f))
                        StatTile("Заряд", "−${(stats.startBat - t.battery).coerceAtLeast(0)}%", Modifier.weight(1f))
                    }
                }
                if (t.error != 0) Text("Код ошибки: ${t.error}", color = Pal.red, fontWeight = FontWeight.Bold)
                TextButton({ confirmOff = true }) { Text("⏻ Выключить самокат", color = Pal.red) }
            }
            if (on && !protoOk && !noData) Text("Ожидание ответа самоката…", color = c.onSurfaceVariant)
            if (on && !protoOk && noData) Glass(Modifier.fillMaxWidth()) {
                Text("Самокат подключён, но не отвечает на протокол M365/Ninebot G30. Управление отключено, чтобы не слать команды вслепую.", fontSize = 13.sp)
                Text(prof.family.note, fontSize = 12.sp, color = c.onSurfaceVariant)
                TextButton({ diag = true }) { Text("Открыть диагностику") }
            }
            Spacer(Modifier.height(4.dp))
        }
        Spacer(Modifier.height(8.dp))
        if (on) GhostButton("Отключить", Modifier.fillMaxWidth()) { ble.disconnect() }
        else GradButton("Найти самокат", Modifier.fillMaxWidth(), onClick = requestScan)
        Text("Автор: limonchik", Modifier.fillMaxWidth().padding(top = 6.dp), textAlign = TextAlign.Center,
            color = c.onSurfaceVariant, fontSize = 11.sp)
    }
    if (about) AboutDialog { about = false }
    if (confirmOff) AlertDialog(
        onDismissRequest = { confirmOff = false }, containerColor = c.surface, shape = RoundedCornerShape(24.dp),
        title = { Text("Выключить самокат?") },
        text = { Text("Команда выключения уйдёт на самокат. Включить его можно только кнопкой.") },
        confirmButton = { TextButton({ confirmOff = false; ble.shutdown() }) { Text("Выключить", color = Pal.red) } },
        dismissButton = { TextButton({ confirmOff = false }) { Text("Отмена") } }
    )
    if (settings) SettingsDialog(vm) { settings = false }
    if (diag) DiagnosticsDialog(vm) { diag = false }
}

// ---------------- Dialogs ----------------
@Composable
fun DiagnosticsDialog(vm: MainViewModel, close: () -> Unit) {
    val ctx = LocalContext.current
    val ble = vm.ble
    val st by ble.state.collectAsState()
    val proto by ble.protoOk.collectAsState()
    val bytes by ble.rawBytes.collectAsState()
    val info by ble.info.collectAsState()
    val gatt by ble.gattDump.collectAsState()
    val frames by ble.frames.collectAsState()
    val prof = profileFor(vm.scooter)
    val c = MaterialTheme.colorScheme
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = c.background) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Диагностика", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                    TextButton(close) { Text("Закрыть") }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Самокат: ${vm.scooter ?: "—"}")
                    Text("Профиль: ${prof.family.title}")
                    Text("Состояние: $st")
                    Text("Протокол M365 отвечает: ${if (proto) "да" else "нет"}")
                    Text("Принято байт: $bytes")
                    if (info.fw.isNotEmpty()) Text("Прошивка: ${info.fw}")
                    if (info.serial.isNotEmpty()) Text("Серийный №: ${info.serial}")
                    Text(prof.family.note, color = c.onSurfaceVariant, fontSize = 13.sp)
                    Text("GATT-сервисы", fontWeight = FontWeight.Medium)
                    Text(gatt.joinToString("\n").ifEmpty { "—" }, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("Кадры (TX/RX)", fontWeight = FontWeight.Medium)
                    Text(frames.joinToString("\n").ifEmpty { "—" }, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton("Очистить", Modifier.weight(1f)) { ble.clearFrames() }
                    GradButton("Отправить отчёт", Modifier.weight(1f)) {
                        try {
                            val i = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, ble.report(vm.scooter ?: "?", prof.family.title))
                            }
                            ctx.startActivity(Intent.createChooser(i, "Отправить отчёт").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {}
                    }
                }
            }
        }
    }
}

@Composable
fun ScanDialog(vm: MainViewModel) {
    val list by vm.ble.found.collectAsState()
    val st by vm.ble.state.collectAsState()
    val msg by vm.ble.msg.collectAsState()
    var all by remember { mutableStateOf(false) }
    val shown = list.filter { all || it.likely }
    AlertDialog(
        onDismissRequest = { vm.closeScan() }, containerColor = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp),
        title = { Text("Выберите самокат") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(all, { all = it }); Text("  Показать все устройства", fontSize = 14.sp)
                }
                if (st == ConnState.SCANNING) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 6.dp))
                if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
                if (shown.isEmpty()) Text("Ничего не найдено. Включите самокат и Bluetooth или нажмите «Показать все».", fontSize = 13.sp)
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(shown) { d ->
                        Row(Modifier.fillMaxWidth().clickable { vm.connect(d.addr) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text((if (d.likely) "🛴 " else "") + d.name.ifBlank { "Без имени" } + (if (d.brand.isNotEmpty()) " · ${d.brand}" else ""), fontWeight = FontWeight.Medium)
                                Text(d.addr, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("${d.rssi} dBm", fontSize = 12.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ vm.ble.startScan() }) { Text("Повторить") } },
        dismissButton = { TextButton({ vm.closeScan() }) { Text("Закрыть") } }
    )
}

@Composable
fun SettingsDialog(vm: MainViewModel, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close, containerColor = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp),
        title = { Text("Настройки") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Тема")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Система", "Светлая", "Тёмная").forEachIndexed { i, n ->
                        FilterChip(vm.theme == i, { vm.changeTheme(i) }, { Text(n, fontSize = 12.sp) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Мили (mph)", Modifier.weight(1f)); Switch(vm.mph, { vm.changeMph(it) }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Не гасить экран", Modifier.weight(1f)); Switch(vm.keepOn, { vm.changeKeepOn(it) }) }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Вибро при заряде ≤15%", Modifier.weight(1f)); Switch(vm.lowAlert, { vm.changeLowAlert(it) }) }
                Text("Вибро при превышении скорости, км/ч")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0, 15, 20, 25, 30).forEach { v ->
                        FilterChip(vm.speedAlert == v, { vm.changeSpeedAlert(v) }, { Text(if (v == 0) "Выкл" else "$v", fontSize = 12.sp) })
                    }
                }
            }
        },
        confirmButton = { TextButton(close) { Text("Готово") } }
    )
}

@Composable
fun AboutDialog(close: () -> Unit) {
    val ctx = LocalContext.current
    val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "" }
    AlertDialog(
        onDismissRequest = close, containerColor = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp),
        title = { Text("E-scooter App $ver") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Автор: limonchik", fontWeight = FontWeight.Bold)
                Text("Управление и диагностика электросамокатов по Bluetooth LE.", fontSize = 13.sp)
                GhostButton("✉️ Связь с разработчиком", Modifier.fillMaxWidth()) { openUrl(ctx, TG_SUPPORT) }
                GhostButton("📢 Канал @EscooterOfficial", Modifier.fillMaxWidth()) { openUrl(ctx, TG_CHANNEL) }
            }
        },
        confirmButton = { TextButton(close) { Text("Закрыть") } }
    )
}

@Composable
fun TgDialog(vm: MainViewModel) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = { vm.dismissTg() }, containerColor = MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(24.dp),
        title = { Text("Подпишитесь на канал 📢") },
        text = { Text("Новости, обновления и советы — в Telegram-канале @EscooterOfficial") },
        confirmButton = { TextButton({ openUrl(ctx, TG_CHANNEL); vm.dismissTg() }) { Text("Подписаться") } },
        dismissButton = { TextButton({ vm.dismissTg() }) { Text("Позже") } }
    )
}
