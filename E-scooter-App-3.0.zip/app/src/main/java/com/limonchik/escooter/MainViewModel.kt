package com.limonchik.escooter

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    val ble = BleClient(app)

    var scooter by mutableStateOf(prefs.scooter)
    var onboarded by mutableStateOf(prefs.onboarded)
    var theme by mutableIntStateOf(prefs.theme)
    var mph by mutableStateOf(prefs.mph)
    var keepOn by mutableStateOf(prefs.keepOn)
    var lowAlert by mutableStateOf(prefs.lowAlert)
    var speedAlert by mutableIntStateOf(prefs.speedAlert)
    var strobeMode by mutableIntStateOf(prefs.strobeMode)
    var strobeSpeed by mutableFloatStateOf(prefs.strobeSpeed)
    var beeping by mutableStateOf(false)
    private val hh = Handler(Looper.getMainLooper())
    private var tone: ToneGenerator? = null
    private val beepRun = object : Runnable {
        override fun run() {
            if (!beeping) return
            try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 200) } catch (_: Throwable) {}
            hh.postDelayed(this, 450)
        }
    }
    fun toggleBeep() {
        if (beeping) { stopBeep(); return }
        try { tone = ToneGenerator(AudioManager.STREAM_ALARM, 100) } catch (_: Throwable) {}
        beeping = true; hh.post(beepRun)
    }
    fun stopBeep() { beeping = false; hh.removeCallbacks(beepRun); try { tone?.release() } catch (_: Throwable) {}; tone = null }
    var showTg by mutableStateOf(false)
    var scanOpen by mutableStateOf(false)
    val userAsked get() = prefs.userAsked

    init { ble.onConnected = { prefs.lastAddr = it } }

    /** Предложение подписаться на канал: ровно один раз, после регистрации. */
    fun maybeShowTg() { if (!prefs.tgPrompted) { showTg = true; prefs.tgPrompted = true } }
    fun dismissTg() { showTg = false }
    fun changeScooter(n: String) { scooter = n; prefs.scooter = n }
    fun saveUser(u: String) { prefs.username = u.trim().removePrefix("@") }
    fun finishOnboarding() { prefs.userAsked = true; prefs.onboarded = true; onboarded = true }
    /** Открывает бота с юзернеймом и моделью — один раз за всё время. */
    fun registerOnce(ctx: Context) {
        val u = prefs.username
        if (!prefs.botSent && !u.isNullOrBlank()) { prefs.botSent = true; openUrl(ctx, botLink(u, scooter ?: "")) }
    }
    fun changeScooter() { onboarded = false }
    fun changeTheme(i: Int) { theme = i; prefs.theme = i }
    fun changeMph(v: Boolean) { mph = v; prefs.mph = v }
    fun changeKeepOn(v: Boolean) { keepOn = v; prefs.keepOn = v }
    fun changeLowAlert(v: Boolean) { lowAlert = v; prefs.lowAlert = v }
    fun changeSpeedAlert(v: Int) { speedAlert = v; prefs.speedAlert = v }
    fun changeStrobeMode(v: Int) { strobeMode = v; prefs.strobeMode = v }
    fun changeStrobeSpeed(v: Float) { strobeSpeed = v; prefs.strobeSpeed = v }
    fun openScan() { scanOpen = true; ble.startScan() }
    fun closeScan() { scanOpen = false; ble.stopScan() }
    fun connect(addr: String) { scanOpen = false; ble.connect(addr) }
    fun autoConnect() {
        val a = prefs.lastAddr ?: return
        val st = ble.state.value
        if ((st == ConnState.IDLE || st == ConnState.ERROR) && !ble.userDisconnected) ble.connect(a)
    }

    override fun onCleared() { stopBeep(); ble.close() }
}
