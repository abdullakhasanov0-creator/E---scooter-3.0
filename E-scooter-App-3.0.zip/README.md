# E-scooter App 3.0 — автор: limonchik
Обновление поверх: APK подписан постоянным ключом app/release.jks, versionCode растёт с номером сборки.
